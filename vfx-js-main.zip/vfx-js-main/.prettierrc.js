module.exports = {
    tabWidth: 4,
};
