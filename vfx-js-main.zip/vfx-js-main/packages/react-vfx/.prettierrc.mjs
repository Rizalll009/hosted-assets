export default {
    tabWidth: 4,
};
