// declare module JSX {
//     interface IntrinsicElements {
//         instancedMesh: any;
//         effectComposer: any;
//         renderPass: any;
//         shaderPass: any;
//     }
// }
