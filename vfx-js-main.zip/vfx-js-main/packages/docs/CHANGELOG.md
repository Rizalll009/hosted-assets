# docs-vfx-js

## 0.0.7

### Patch Changes

-   Updated dependencies
    -   @vfx-js/core@0.5.2

## 0.0.6

### Patch Changes

-   Updated dependencies
    -   @vfx-js/core@0.5.1

## 0.0.5

### Patch Changes

-   Updated dependencies
    -   @vfx-js/core@0.5.0

## 0.0.4

### Patch Changes

-   Updated dependencies
    -   @vfx-js/core@0.4.1

## 0.0.3

### Patch Changes

-   Updated dependencies
    -   @vfx-js/core@0.4.0

## 0.0.2

### Patch Changes

-   Updated dependencies
    -   @vfx-js/core@0.3.0

## 0.0.1

### Patch Changes

-   Updated dependencies
    -   @vfx-js/core@0.2.0
