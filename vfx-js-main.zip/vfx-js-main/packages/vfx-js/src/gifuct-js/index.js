import GIF from "./gif.js";
export default GIF;
