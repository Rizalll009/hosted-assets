# react-vfx

## 0.5.2

### Patch Changes

-   Fix pixelRatio not working

## 0.5.1

### Patch Changes

-   Fix intersection calculation on VFX.add()

## 0.5.0

### Minor Changes

-   Add intersection options

## 0.4.1

### Patch Changes

-   Fix texture update bug on canvas resize

## 0.4.0

### Minor Changes

-   Add canvas support etc

## 0.3.0

### Minor Changes

-   Migrate to ESM

## 0.2.0

### Minor Changes

-   Add shaders and fixed minor bugs

## 0.6.2

### Patch Changes

-   Fix initial loading bug
